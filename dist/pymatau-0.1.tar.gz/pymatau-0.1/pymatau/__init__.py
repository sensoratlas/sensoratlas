# app config
default_app_config = 'pymatau.apps.SensorAppConfig'
