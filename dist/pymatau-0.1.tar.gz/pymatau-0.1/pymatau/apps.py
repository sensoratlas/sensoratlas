from django.apps import AppConfig


class PyMatauConfig(AppConfig):
    name = 'pymatau'
    verbose_name = 'Sensor Things'
