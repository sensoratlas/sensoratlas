# from rest_framework import status
# from rest_framework.test import APITestCase
# from sensorthings.models import Thing, Location, DataStream, Sensor, \
#     ObservedProperty, Observation, FeatureOfInterest
# from django.contrib.gis.geos import Point, Polygon
# from django.utils import timezone
# from operator import getitem
#
#
# class BatchRequest(APITestCase):
#     """
#     test id
#     requirements
#     test purpose
#     test method
#     """
#     # here are the tests
