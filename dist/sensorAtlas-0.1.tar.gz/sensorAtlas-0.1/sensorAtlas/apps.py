from django.apps import AppConfig


class sensorAtlasConfig(AppConfig):
    name = 'sensorAtlas'
    verbose_name = 'Sensor Atlas'
