# app config
default_app_config = 'sensorAtlas.apps.SensorAppConfig'
